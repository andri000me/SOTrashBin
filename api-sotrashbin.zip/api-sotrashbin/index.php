<html>
<head>
    <meta http-equiv="refresh" content="2">
</head> 
<body>
<head>
    <title>Raspberry Pi Weather Log</title>
    <style type="text/css">
        .table_titles, .table_cells_odd, .table_cells_even {
                padding-right: 20px;
                padding-left: 20px;
                color: #000;
        }
        .table_titles {
            color: #FFF;
            background-color: #666;
        }
        .table_cells_odd {
            background-color: #CCC;
        }
        .table_cells_even {
            background-color: #FAFAFA;
        }
        table {
            border: 2px solid #333;
        }
        body { font-family: "Trebuchet MS", Arial; }
    </style>
</head>
<?php
  $servername = "localhost";
  $username = "alwiyahy_jancuk";
  $password = "alwiyahya99";
  $dbname = "alwiyahy_temperature";
  $conn =mysqli_connect($servername, $username, $password,     $dbname);
    if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
        } 
     $query = "SELECT * FROM data ORDER BY id DESC";
     $result = $conn->query($query);
     if ($result ->num_rows > 0) {
    echo "<center>";
    echo "<h1>Raspberry Pi</h1>";
    echo "<h1>Weather and Soil Moisture Log</h1>";
    echo "<table border='0' cellspacing='0' cellpadding='4'><th class='table_titles'>Date and Time</th><th class='table_titles'>Temperature (⁰C)</th><th class='table_titles'>Humidity %</th><th class='table_titles'>Soil Moisture %</th>";
		while($row = $result->fetch_assoc()) {
			echo "<tr>";
// 			echo "<td  style='text-align:center'>".$row['id']."</td>";
			echo "<td  style='text-align:center'>".$row['date']."</td>";
			echo "<td  style='text-align:center'>".$row['temperature']."</td>";
			echo "<td  style='text-align:center'>".$row['humidity']."</td>";
			echo "<td  style='text-align:center'>".$row['pressure']."</td>";
			echo "</tr>";
			}
		echo "</table>";
	} else {
		echo "data kosong ";
    }
     $conn->close();
?>
</body>
</html>

