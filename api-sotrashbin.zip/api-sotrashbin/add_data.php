<?php
	//ini untuk mendeklarasikan database
	$servername = "localhost";
	$username = "chiqorsx_root";
	$password = "p-JPyF0p0pzN";
	$dbname = "chiqorsx_sotrashbin";
	$conn = new mysqli($servername, $username,$password, $dbname);
    
	// memeriksa apakah sudah terkoneksi ke database
	if ($conn->connect_error) {
		die("Connection failed : " . $conn->connect_error);
	}
	
	date_default_timezone_set('Asia/Jakarta');
    $dateS = date('Y-m-d h:i:s', time());
    echo $dateS."<br>";
	
	$kode_seri = $_GET['kode_seri'];
	$jarak = $_GET['jarak'];
	$level = $_GET['level'];
	$kelembapan = $_GET['kelembapan'];
	$suhu = $_GET['suhu'];
	$berat = $_GET['berat'];
    
	$query = "INSERT INTO aktifitas
	        (kode_seri,jarak,level,kelembapan,suhu,berat,waktu_daftar) 
	        VALUES 
	        ('$kode_seri',$jarak,$level,$kelembapan,$suhu,$berat,'$dateS')";
	if ($conn->query($query) === TRUE) {
	    echo "Sukses Menyimpan ke database!";
	} else {
		echo "Error:" . $query. "<br>" . $conn->error;
	}
	$conn->close();
?>